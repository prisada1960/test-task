<?php
/*
Решение реализовано на PHP с использованием PhpSpreadsheet и XMLWriter.

Функционал:

обновление цен из прайса
генерация old_price (+10%)
подсветка изменений в Excel
XML генерация для маркетплейсов
chunk processing для обработки больших объемов данных

Скрипт оптимизирован для работы с 10 000+ товаров и подходит для серверного запуска/cron automation.

Установка библиотек

Через Composer:
composer require phpoffice/phpspreadsheet
*/
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// ======================================
// НАСТРОЙКИ
// ======================================

// Файл импорта
$importFile = 'Import.xlsx';

// Прайс с актуальными ценами
$priceFile = 'Тепла підлога прайс 2024.xlsx';

// Файл результата Excel
$outputExcel = 'result/updated_import.xlsx';

// XML файл для маркетплейса
$outputXml = 'result/marketplace.xml';

// Размер чанка (сколько строк обрабатываем за раз)
$chunkSize = 1000;

// ======================================
// СОЗДАНИЕ ПАПКИ RESULT
// ======================================

if (!file_exists('result')) {
    mkdir('result', 0777, true);
}

// ======================================
// ЗАГРУЗКА EXCEL ФАЙЛОВ
// ======================================

echo "Загрузка Excel файлов...\n";

// Загружаем импорт
$importSpreadsheet = IOFactory::load($importFile);

// Загружаем прайс
$priceSpreadsheet = IOFactory::load($priceFile);

// Получаем активные листы
$importSheet = $importSpreadsheet->getActiveSheet();
$priceSheet = $priceSpreadsheet->getActiveSheet();

// ======================================
// ЧТЕНИЕ ПРАЙСА
// ======================================

echo "Подготовка прайса...\n";

// Массив вида:
// [sku => price]
$priceData = [];

// Преобразуем Excel в массив
$priceRows = $priceSheet->toArray();

// Перебираем строки прайса
foreach ($priceRows as $index => $row) {

    // Пропускаем заголовок
    if ($index === 0) {
        continue;
    }

    // SKU товара
    $sku = $row[0];

    // Цена товара
    $price = $row[1];

    // Сохраняем в массив
    $priceData[$sku] = $price;
}

// ======================================
// ОБРАБОТКА IMPORT ФАЙЛА
// ======================================

echo "Обработка импорта...\n";

// Получаем все строки
$rows = $importSheet->toArray();

// Заголовки
$headers = $rows[0];

// Массив для XML
$changedRows = [];

// ======================================
// ОБРАБОТКА ЧАНКАМИ
// ======================================

// Идем по 1000 строк
for ($i = 1; $i < count($rows); $i += $chunkSize) {

    // Получаем часть массива
    $chunk = array_slice($rows, $i, $chunkSize);

    // Перебираем chunk
    foreach ($chunk as $chunkIndex => $row) {

        // Настоящий номер строки Excel
        $realIndex = $i + $chunkIndex + 1;

        // SKU товара
        $sku = $row[0];

        // Текущая цена
        $currentPrice = $row[1];

        // Если товар найден в прайсе
        if (isset($priceData[$sku])) {

            // Новая цена
            $newPrice = $priceData[$sku];

            // old_price = +10%
            $oldPrice = round($newPrice * 1.10, 2);

            // ======================================
            // ОБНОВЛЕНИЕ EXCEL
            // ======================================

            // Колонка B = новая цена
            $importSheet->setCellValue(
                'B' . $realIndex,
                $newPrice
            );

            // Колонка C = old_price
            $importSheet->setCellValue(
                'C' . $realIndex,
                $oldPrice
            );

            // ======================================
            // ПОДСВЕТКА СТРОК
            // ======================================

            // Если цена изменилась
            if ($currentPrice != $newPrice) {

                // Зеленый цвет
                $fillColor = 'C6EFCE';

            } else {

                // Серый цвет
                $fillColor = 'D9D9D9';
            }

            // Закрашиваем строку
            $importSheet
                ->getStyle("A{$realIndex}:C{$realIndex}")
                ->getFill()
                ->setFillType(Fill::FILL_SOLID)
                ->getStartColor()
                ->setARGB($fillColor);

            // ======================================
            // ДОБАВЛЯЕМ В XML
            // ======================================

            $changedRows[] = [
                'sku' => $sku,
                'price' => $newPrice,
                'old_price' => $oldPrice
            ];
        }
    }

    // Лог обработки
    echo "Обработан chunk: {$i}\n";
}

// ======================================
// СОХРАНЕНИЕ EXCEL
// ======================================

echo "Сохранение Excel...\n";

// Создаем writer
$writer = IOFactory::createWriter(
    $importSpreadsheet,
    'Xlsx'
);

// Сохраняем файл
$writer->save($outputExcel);

// ======================================
// ГЕНЕРАЦИЯ XML
// ======================================

echo "Генерация XML...\n";

// Создаем XML writer
$xml = new XMLWriter();

// Открываем файл
$xml->openURI($outputXml);

// Начало XML
$xml->startDocument(
    '1.0',
    'UTF-8'
);

// Красивое форматирование
$xml->setIndent(true);

// Корневой элемент
$xml->startElement('products');

// Перебираем товары
foreach ($changedRows as $product) {

    // Товар
    $xml->startElement('product');

    // SKU
    $xml->writeElement(
        'sku',
        $product['sku']
    );

    // Цена
    $xml->writeElement(
        'price',
        $product['price']
    );

    // Старая цена
    $xml->writeElement(
        'old_price',
        $product['old_price']
    );

    // Закрываем product
    $xml->endElement();
}

// Закрываем products
$xml->endElement();

// Конец XML
$xml->endDocument();

// Записываем файл
$xml->flush();

// ======================================
// ГОТОВО
// ======================================

echo "Готово!\n";

echo "Excel сохранен: {$outputExcel}\n";

echo "XML сохранен: {$outputXml}\n";